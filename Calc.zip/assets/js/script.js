let input = document.getElementById("input");
let button = document.querySelectorAll("#number");
let result = document.querySelector(".result");
let c = document.getElementById("c");
let del = document.getElementById("del");
let mainInput = document.querySelector(".main__input");
let animate = "headShake";
let animateC = "fadeOut";
let animateDel = "pulse";
let animateRes = "fadeIn";
let wh = document.getElementById("w");
let bl = document.getElementById("b");
let hr = document.querySelectorAll(".herz");
let burger = document.querySelector("#body");
let calc = document.querySelector(".all");
let color;
let itemsArray = localStorage.getItem("color")
  ? JSON.parse(localStorage.getItem("color"))
  : [];
const data = JSON.parse(localStorage.getItem("color"));
localStorage.setItem("color", JSON.stringify(itemsArray));

new WOW().init();

[].forEach.call(button, function (el) {
  el.style.cssText = del.style.cssText = c.style.cssText = data[0];
  el.onclick = function (e) {
    setTimeout(() => {
      mainInput.classList.remove(animate);
    }, 500);
    input.value += el.value;
    mainInput.classList.add(animate);
  };
});
result.onclick = function (e) {
  setTimeout(() => {
    mainInput.classList.remove(animateRes);
  }, 500);
  if (
    input.value == "0/0" ||
    input.value == "2+2" ||
    input.value == "1+1" ||
    input.value == "0+0"
  ) {
    result = "Какой ты умный....)";
    input.value = result;
  } else {
    result = eval(input.value);

    if (result == "Infinity") {
      result = "На ноль делить нельзя, учи математику (";
    }
    if (input.value == "2+2") {
      result = "Ещё не вырос, иди учись )";
    }
    if (result == "NaN") {
      result == "Мммм... Что-то сдесь не так)";
    }

    input.value = result;
  }
  mainInput.classList.add(animateRes);
};

c.onclick = function (e) {
  setTimeout(() => {
    mainInput.classList.remove(animateC);
  }, 700);
  mainInput.classList.add(animateC);
  c = "";
  setTimeout(() => {
    input.value = c;
  }, 600);
};

del.onclick = function (e) {
  setTimeout(() => {
    mainInput.classList.remove(animateDel);
  }, 700);
  mainInput.classList.add(animateDel);
  input.value = input.value.slice(0, -1);
};

wh.onchange = function (e) {
  localStorage.clear();
  itemsArray = [];
  color = "background-color: #d2dae2; color: black;";
  itemsArray.push(color);
  localStorage.setItem("color", JSON.stringify(itemsArray));
  [].forEach.call(button, function (el) {
    el.style.cssText = del.style.cssText = c.style.cssText = data[0];
    el.style.cssText = del.style.cssText = c.style.cssText = color;
  });
};

bl.onchange = function (e) {
  localStorage.clear();
  itemsArray = [];
  color = "background-color: #2c3e50; color: white;";
  itemsArray.push(color);
  localStorage.setItem("color", JSON.stringify(itemsArray));
  [].forEach.call(button, function (el) {
    el.style.cssText = del.style.cssText = c.style.cssText = data[0];
    el.style.cssText = del.style.cssText = c.style.cssText = color;
  });
};

[].forEach.call(hr, function (el) {
  el.onclick = function (e) {
    burger.classList.toggle("visible");
    calc.classList.toggle("hidden");
  };
});
